const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const Student_loginSchema = new Schema({
    name:{
        type: String,
        required: true,
    },
    email:{
        type: String,
        required: true,
        unique: true
    },
    password:{
        type: String,
        required: true,
    }
});

const StudentModel = mongoose.model('student_logins', Student_loginSchema);
module.exports = StudentModel;