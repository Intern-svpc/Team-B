require('dotenv').config();
const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const cors = require ('cors');
const StudentRouter = require('./Routers/StudentRouter')
const ProductRouter = require('./Routers/ProductRouter')


require('./Models/db');
const PORT = process.env.PORT || 8080;
app.use(bodyParser.json());
// app.get("/ping", (req, res)=>{
//     res.send('PONG');
// });


app.use(cors());
app.use('/stud', StudentRouter); // /auth
app.use('/product', ProductRouter);


app.listen(PORT, ()=>{
    console.log(`Server is running on port ${PORT}`);
})