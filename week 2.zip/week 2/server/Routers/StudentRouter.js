const {signup, login} = require('../Controllers/StudentController');
const { signupValidation, loginValidation } = require('../Middlewares/StudentValidation');

const router = require('express').Router();


// router.post('/login', (req, res)=>{
//     res.send('login success');
// });

// router.post('/signup', (req, res)=>{
//     res.send('Signup success');
// });
router.post('/login', loginValidation, login);
router.post('/signup', signupValidation, signup);

module.exports = router;