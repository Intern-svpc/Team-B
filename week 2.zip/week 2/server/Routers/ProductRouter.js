const ensureAuthenticated = require('../Middlewares/Auth');

const router = require('express').Router();

router.get('/', ensureAuthenticated,(req, res)=>{
    console.log("kkj: ", req.Student_login);
    res.status(200).json([
        {
            name: "mobile",
            price: 1000
        },
        {
            name: "tv",
            price:2000
        }
    ])
});

module.exports = router;