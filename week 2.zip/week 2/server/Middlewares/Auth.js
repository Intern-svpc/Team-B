const jwt = require('jsonwebtoken');
const ensureAuthenticated = (req, res, next)=>{
    const auth = req.headers['authorization'];
    if(!auth){
        return res.status(403)
            .json({message:'Access denied. token required.'});
    }
    try{
        const decoded = jwt.verify(auth, process.env.JWT_SECRET);
        req.Student_login = decoded;
        next();
    }catch(err){
        return res.status(403)
            .json({message:'Access denied. Invalid token.'});
    }
};

module.exports = ensureAuthenticated;