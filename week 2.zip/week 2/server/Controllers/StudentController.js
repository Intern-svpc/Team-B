require('dotenv').config(); 
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const StudentModel = require("../Models/Student_login");


const signup = async (req, res)=>{
    try{
        const {name, email, password}=req.body;
        const Student_login = await StudentModel.findOne({email});
        if (Student_login){
            return res.status(409)
            .json({message: "User is already exists, you can login", success: false});
        }
        const studentModel = new StudentModel({name, email, password});
        studentModel.password = await bcrypt.hash(password, 10);
        await studentModel.save();
        res.status(201)
        .json({
            message: "Signup successfully",
            success: true
        })

    } catch(err){
        res.status(500)
        .json({
            message: "Internal Server Error",
            success: false
        })
    }
}

const login = async (req, res)=>{
    try{
        const {email, password}=req.body;
        const Student_login = await StudentModel.findOne({email});
        const errorMsg = "Authentication failed, incorrect email or password!";
        if (!Student_login){
            return res.status(403)
                .json({message: errorMsg, success: false});
        }
        const isPassEqual = await bcrypt.compare(password, Student_login.password);
        if (!isPassEqual){
            return res.status(403)
                .json({message: errorMsg, success: false});
        }
        const jwtToken = jwt.sign(
            {email: Student_login.email, _id: Student_login._id},
            process.env.JWT_SECRET,
            {expiresIn: '24h'}
        )

        res.status(200)
        .json({
            message: "Login successfully",
            success: true,
            jwtToken,
            email,
            name: Student_login.name
        })

    } catch(err){
        res.status(500)
        .json({
            message: "Internal Server Error",
            success: false
        })
    }
}
// const login = async (req, res)=>{
//     try{
//         const {name, email, password}=req.body;
//         const Student_login = await StudentModel.findOne({email});
//         const errorMsg = "Authorization is failed email or password is wrong.";
//         if (!Student_login){
//             return res.status(403)
//             .json({message: errorMsg, success: false});
//         }
//         const isPassEqual = await bcrypt.compare(password, Student_login.password);
//         if(!isPassEqual){
//             return res.status(403)
//             .json({message: errorMsg, success: false});
//         }
        
//         const jwtToken = jwt.sign({email: Student_login.email, _id: Student_login._id},
//             process.env.SECRET_KEY, 
//             {expiresIn: "24h"}
//         );
        
//         res.status(20)
//         .json({
//             message: "Login successfully",
//             success: true,
//             jwtToken,
//             email,
//             name: Student_login.name
//         })

//     } catch(err){
//         res.status(500)
//         .json({
//             message: "Internal Server Error",
//             success: false
//         })
//     }
// }

module.exports = {
    signup,
    login
}