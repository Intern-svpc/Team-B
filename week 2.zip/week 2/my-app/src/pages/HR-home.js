import React from 'react'
import './HR-home.css'

function HRHome(){
    return(
        <div>Home</div>
    )
}
export default HRHome;