// StudHome.js
import React from 'react';
import { Link } from 'react-router-dom';
import './Home.css';

function StudHome() {
  const roles = [
    {
      title: "Student Portal",
      description: "Access course materials, submit assignments, and track academic progress.",
      path: "/Student-login",
      color: "#f8f9fa"
    },
    {
      title: "Mentor Portal",
      description: "Guide student development, monitor progress, and provide feedback.",
      path: "/mentor-login",
      color: "#e9ecef"
    },
    {
      title: "Faculty Portal",
      description: "Manage courses, upload resources, and evaluate student work.",
      path: "/teacher-login",
      color: "#dee2e6"
    },
    {
      title: "HR Portal",
      description: "Access employee records, manage institutional resources, and handle administration.",
      path: "/HR-login",
      color: "#ced4da"
    }
  ];

  return (
    <div className="portal-container">
      <h1 className="portal-header">Institutional Access Portal</h1>
      <div className="cards-container">
        {roles.map((role, index) => (
          <div key={index} className="access-card" style={{ backgroundColor: role.color }}>
            <div className="card-content">
              <h3 className="card-title">{role.title}</h3>
              <p className="card-description">{role.description}</p>
              <Link to={role.path} className="access-button">
                Secure Login →
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default StudHome;