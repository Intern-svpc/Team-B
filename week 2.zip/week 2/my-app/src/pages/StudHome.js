import React from 'react'
import './StudHome.css'

function StudHome(){
    return(
        <div>Home</div>
    )
}
export default StudHome;