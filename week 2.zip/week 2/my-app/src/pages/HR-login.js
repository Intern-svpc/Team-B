import React from 'react'
import './HR-login.css'

function HRLogin(){
    return(
        <div>Login</div>
    )
}
export default HRLogin;