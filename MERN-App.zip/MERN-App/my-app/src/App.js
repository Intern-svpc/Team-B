  // import logo from './logo.svg';
// import './App.css';
// import 'bootstrap/dist/css/bootstrap.min.css'
import {Navigate, Routes, Route } from 'react-router-dom';
import StudLogin from './pages/StudLogin';
import StudSignup from './pages/StudSignup';
import StudHome from './pages/StudHome';
import Home from './pages/Home';
import HRLogin from './pages/HR-login';
import HRHome from './pages/HR-home';
import HRSignup from './pages/HR-signup';
import Admin from './pages/Admin';

function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/Student-login" element={<StudLogin />} />
        <Route path="/Student-signup" element={<StudSignup />} />
        <Route path="/Student-home" element={<StudHome />} />
        <Route path='/Student' element={<Navigate to='/Student-home' />} />
        <Route path="/Home" element={<Home />} />
        <Route path='/' element={<Navigate to='/Home' />} />
        <Route path="/HR-login" element={<HRLogin />} />
        <Route path="/HR-signup" element={<HRSignup />} />
        <Route path="/HR-home" element={<HRHome />} />
        <Route path='/HR' element={<Navigate to='/HR-home' />} />
        <Route path="/Admin" element={<Admin />} />
      </Routes>
    </div>
  );
}

export default App;
