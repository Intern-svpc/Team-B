import { toast } from "react-toastify";

export const handleSuccess = (msg) => {
    toast.success(msg, {
        position: "top-right",
        theme: "colored"
    });
}

export const handleError = (msg) => {
    toast.error(msg, {  // Changed from toast.success to toast.error
        position: "top-right",
        theme: "colored"
    });
}