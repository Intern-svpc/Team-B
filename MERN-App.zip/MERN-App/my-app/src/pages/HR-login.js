import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ToastContainer} from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { handleError, handleSuccess } from '../utils';
import './HR-login.css';

const HRLogin = () => {
  const [isActive, setIsActive] = useState(false);
  const [HRLoginInfo, setHRLoginInfo] = useState({ email: '', password: '' });
  const [HRSignupInfo, setHRSignupInfo] = useState({
    name: '',
    email: '',
    password: '',
    company: ''
  });
  const navigate = useNavigate();

  useEffect(() => {
    document.title = isActive ? "HR Registration - Portal" : "HR Login - Portal";
  }, [isActive]);

  const handleSignupSubmit = async (e) => {
    e.preventDefault();
    const { name, email, password, company } = HRSignupInfo;
    if (!name || !email || !password || !company) {
      return handleError("All fields are required");
    }
    try {
      const response = await fetch("http://localhost:8080/hr/signup", {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(HRSignupInfo)
      });
      const result = await response.json();
      if (result.success) {
        handleSuccess(result.message);
        setTimeout(() => {
          setIsActive(false);
          setHRSignupInfo({ name: '', email: '', password: '', company: '' });
          setHRLoginInfo(prev => ({ ...prev, email }));
        }, 1000);
      } else {
        handleError(result.message || result.error);
      }
    } catch (err) {
      handleError(err.message);
    }
  };

  const handleLoginSubmit = async (e) => {
    e.preventDefault();
    const { email, password } = HRLoginInfo;
    if (!email || !password) {
      return handleError("Email and password are required");
    }
    try {
      const response = await fetch("http://localhost:8080/hr/login", {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(HRLoginInfo)
      });
      const result = await response.json();
      if (result.success) {
        handleSuccess(result.message);
        localStorage.setItem('token', result.token);
        localStorage.setItem('loggedInHR', result.name);
        setTimeout(() => {
          navigate('/HR-home');
          setHRLoginInfo({ email: '', password: '' });
        }, 1000);
      } else {
        handleError(result.message || result.error);
      }
    } catch (err) {
      handleError(err.message);
    }
  };

  return (
    <div className={`container ${isActive ? 'active' : ''}`}>
      <ToastContainer position="top-right" autoClose={5000} />
      <div className="form-box login">
        <form onSubmit={handleLoginSubmit}>
          <h1>HR Login</h1>
          <input type="text" name="email" placeholder="Email" value={HRLoginInfo.email} onChange={(e) => setHRLoginInfo({ ...HRLoginInfo, email: e.target.value })} required />
          <input type="password" name="password" placeholder="Password" value={HRLoginInfo.password} onChange={(e) => setHRLoginInfo({ ...HRLoginInfo, password: e.target.value })} required />
          <button type="submit">Login</button>
        </form>
      </div>
      <div className="form-box register">
        <form onSubmit={handleSignupSubmit}>
          <h1>HR Registration</h1>
          <input type="text" name="name" placeholder="Full Name" value={HRSignupInfo.name} onChange={(e) => setHRSignupInfo({ ...HRSignupInfo, name: e.target.value })} required />
          <input type="email" name="email" placeholder="Email" value={HRSignupInfo.email} onChange={(e) => setHRSignupInfo({ ...HRSignupInfo, email: e.target.value })} required />
          <input type="password" name="password" placeholder="Password" value={HRSignupInfo.password} onChange={(e) => setHRSignupInfo({ ...HRSignupInfo, password: e.target.value })} required />
          <input type="text" name="company" placeholder="Company Name" value={HRSignupInfo.company} onChange={(e) => setHRSignupInfo({ ...HRSignupInfo, company: e.target.value })} required />
          <button type="submit">Register</button>
        </form>
      </div>
      <div className="toggle-box">
        <div className="toggle-panel toggle-left">
          <h1>Welcome!</h1>
          <p>Don't have an account?</p>
          <button onClick={() => setIsActive(true)}>Register</button>
        </div>
        <div className="toggle-panel toggle-right">
          <h1>Welcome Back!</h1>
          <p>Already have an account?</p>
          <button onClick={() => setIsActive(false)}>Login</button>
        </div>
      </div>
    </div>
  );
};

export default HRLogin;
