import React, { useEffect, useState } from "react";
import './Admin.css';

const Admin = () => {
    const [hrCount, setHrCount] = useState(0);
    const [opportunityCount, setOpportunityCount] = useState(0);
    const [jdRequests, setJdRequests] = useState([]);

    useEffect(() => {
        fetchHrCount();
        fetchOpportunityCount();
        fetchJDs();
    }, []);

    const fetchHrCount = async () => {
        try {
            const response = await fetch("http://localhost:8080/admin/hrs/count");
            const data = await response.json();
            if (response.ok) {
                setHrCount(data.count);
            }
        } catch (error) {
            console.error("Error fetching HR count:", error);
        }
    };

    const fetchOpportunityCount = async () => {
        try {
            const response = await fetch("http://localhost:8080/admin/jds/count");
            const data = await response.json();
            if (response.ok) {
                setOpportunityCount(data.count);
            }
        } catch (error) {
            console.error("Error fetching Opportunity count:", error);
        }
    };

    const fetchJDs = async () => {
        const token = localStorage.getItem("token");
        try {
            const response = await fetch("http://localhost:8080/admin/jds", {
                method: "GET",
                headers: {
                    "Authorization": `Bearer ${token}`,
                    "Content-Type": "application/json",
                },
            });

            const data = await response.json();
            if (response.ok) {
                const filteredJDs = data.jds.filter(jd => jd.status === 2);
                filteredJDs.sort((a, b) => new Date(b.date) - new Date(a.date));
                setJdRequests(filteredJDs);
            }
        } catch (error) {
            console.error("Error fetching JDs:", error);
        }
    };

    const toggleExpand = (index, event) => {
        if (event.target.tagName.toLowerCase() !== 'button') {
            setJdRequests(jdRequests.map((jd, i) => (i === index ? { ...jd, expanded: !jd.expanded } : jd)));
        }
    };

    const handleAction = async (id, status) => {
        const token = localStorage.getItem("token");
        try {
            const response = await fetch(`http://localhost:8080/admin/jds/${id}`, {
                method: "PUT",
                headers: {
                    "Authorization": `Bearer ${token}`,
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ status }),
            });

            if (response.ok) {
                fetchJDs();
            }
        } catch (error) {
            console.error("Error updating JD status:", error);
        }
    };

    return (
        <div style={{ padding: "20px", background: "#f0f2f5" }}>
            <div className="header">Admin Panel</div>
            <div className="stats-container">
                <div className="stats-box">
                    <h2>No. of HR (Human Resources)</h2>
                    <p>{hrCount}</p>
                </div>
                <div className="stats-box">
                    <h2>No. of Opportunities</h2>
                    <p>{opportunityCount}</p>
                </div>
            </div>
            <div className="jd-list">
                <h2>Job Description Requests</h2>
                {jdRequests.map((jd, index) => (
                    <div key={index} className="jd-item" onClick={(e) => toggleExpand(index, e)}>
                        <div className="jd-header">
                            <div className="jd-details">
                                <h3>{jd.position}</h3>
                                <p><strong>Company:</strong> {jd.hrId?.company}</p>
                                <p><strong>Location:</strong> {jd.location}</p>
                                <p><strong>CTC:</strong> {jd.ctc}</p>
                                <p><strong>Skills:</strong> {jd.skills}</p>
                                <p><strong>Type:</strong> {jd.type}</p>
                                <p><strong>Post Date:</strong> {jd.date}</p>
                                <button onClick={() => handleAction(jd._id, 1)} className="accept-btn">Accept</button>
                                <button className="reject-btn">Reject</button>
                            </div>
                        </div>
                        {jd.expanded && (
                            <div className="jd-expanded active">
                                <div className="detail-section">
                                    <h4>Description:</h4>
                                    <p>{jd.description}</p>
                                </div>
                            </div>
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Admin;
