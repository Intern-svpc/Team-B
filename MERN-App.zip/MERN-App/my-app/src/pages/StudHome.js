import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './StudHome.css';

const StudHome = () => {
    const [jds, setJds] = useState([]);
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchJds = async () => {
            const token = localStorage.getItem('token');
            if (!token) {
                setError('Authentication token is missing. Please login again.');
                setLoading(false);
                return;
            }
            try {
                const response = await axios.get('http://localhost:8080/stud/jds', {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                });
                setJds(response.data.jds);
                setLoading(false);
            } catch (err) {
                setError('Failed to fetch job descriptions.');
                setLoading(false);
                console.error(err);
            }
        };
        fetchJds();
    }, []);

    const handleApply = (jdId) => {
        // Implement your apply logic here
        console.log(`Applied to job with ID: ${jdId}`);
    };

    // Function to format date
    const formatDate = (dateString) => {
        const options = { year: 'numeric', month: 'short', day: 'numeric' };
        return new Date(dateString).toLocaleDateString(undefined, options);
    };

    // Check if job was posted within the last 7 days
    const isNewJob = (dateString) => {
        if (!dateString) return false;
        const postDate = new Date(dateString);
        const now = new Date();
        const diffTime = Math.abs(now - postDate);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        return diffDays <= 7;
    };

    return (
        <div className="student-home-container">
            <div className="header">
                <h2>Student Panel</h2>
                <p>Discover and apply for positions that match your skills and interests</p>
            </div>
            
            {error && <div className="error-message">
                <i className="fas fa-exclamation-circle"></i> {error}
            </div>}
            
            {loading ? (
                <div className="loading">
                    <i className="fas fa-spinner fa-spin"></i> Loading available positions...
                </div>
            ) : jds.length > 0 ? (
                <div className="jd-container">
                    {jds.map((jd) => (
                        <div key={jd._id} className="jd-card">
                            <div className="jd-header">
                                <h3>
                                    {jd.position}
                                    {isNewJob(jd.createdAt) && 
                                        <span className="badge badge-new">New</span>
                                    }
                                </h3>
                                <div className="jd-company">
                                    <i className="fas fa-building"></i>
                                    {jd.hrId?.company || 'Company Name'} 
                                </div>
                            </div>
                            
                    <div className="jd-content">
                        <div className="jd-meta">
                            {jd.location && (
                                <div className="jd-meta-item">
                                    <i className="fas fa-map-marker-alt"></i>
                                    <span><strong>Location:</strong> {jd.location}</span>
                                </div>
                            )}
                            {jd.jobType && (
                                <div className="jd-meta-item">
                                    <i className="fas fa-briefcase"></i>
                                    <span><strong>Job Type:</strong> {jd.jobType}</span>
                                </div>
                            )}
                            {jd.ctc && (
                                <div className="jd-meta-item">
                                    <i className="fas fa-money-bill-wave"></i>
                                    <span><strong>CTC:</strong> {jd.ctc}</span>
                                </div>
                            )}
                            {jd.skills && (
                                <div className="jd-meta-item">
                                    <i className="fas fa-tools"></i>
                                    <span><strong>Skills:</strong> {jd.skills}</span>
                                </div>
                            )}
                            </div>  
                                <div className="jd-description">
                                    {jd.description}
                                </div>
                            </div>
                            
                            <div className="jd-footer">
                                <div className="posted-date">
                                    <i className="far fa-calendar-alt"></i>
                                    Posted: {jd.date ? formatDate(jd.date) : ''}
                                </div>

                                <button 
                                    className="apply-button"
                                    onClick={() => handleApply(jd._id)}>
                                    <i className="fas fa-paper-plane"></i>
                                    Apply Now
                                </button>
                            </div>
                        </div>
                    ))}
                    </div>
            ) : (
                <div className="no-jobs">
                    <div className="no-jobs-icon">
                        <i className="fas fa-briefcase"></i>
                    </div>
                    <p>No job opportunities available at the moment. Please check back later.</p>
                </div>
            )}
        </div>
    );
};

export default StudHome;