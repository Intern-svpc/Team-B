import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { handleError, handleSuccess } from '../utils';
import './StudLogin.css';

const StudLogin = () => {
  const [isActive, setIsActive] = useState(false);
  const [studLoginInfo, setStudLoginInfo] = useState({ email: '', password: '' });
  const [studSignupInfo, setStudSignupInfo] = useState({
    name: '',
    email: '',
    password: '',
    college: ''
  });
  const navigate = useNavigate();

  useEffect(() => {
    document.title = isActive ? "Student Registration - Portal" : "Student Login - Portal";
  }, [isActive]);

  const handleSignupSubmit = async (e) => {
    e.preventDefault();
    const { name, email, password, college } = studSignupInfo;
    if (!name || !email || !password || !college) {
      return handleError("All fields are required");
    }
    try {
      const response = await fetch("http://localhost:8080/stud/signup", {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(studSignupInfo)
      });
      const result = await response.json();
      if (result.success) {
        handleSuccess(result.message);
        setTimeout(() => {
          setIsActive(false);
          setStudSignupInfo({ name: '', email: '', password: '', college: '' });
          setStudLoginInfo(prev => ({ ...prev, email }));
        }, 1000);
      } else {
        handleError(result.message || result.error);
      }
    } catch (err) {
      handleError(err.message);
    }
  };

  const handleLoginSubmit = async (e) => {
    e.preventDefault();
    const { email, password } = studLoginInfo;
    if (!email || !password) {
      return handleError("Email and password are required");
    }
    try {
      const response = await fetch("http://localhost:8080/stud/login", {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(studLoginInfo)
      });
      const result = await response.json();
      if (result.success) {
        handleSuccess(result.message);
        localStorage.setItem('token', result.token);
        localStorage.setItem('loggedInStudent', result.name);
        setTimeout(() => {
          navigate('/Student-home');
          setStudLoginInfo({ email: '', password: '' });
        }, 1000);
      } else {
        handleError(result.message || result.error);
      }
    } catch (err) {
      handleError(err.message);
    }
  };

  return (
    <div className={`container ${isActive ? 'active' : ''}`}>
      <ToastContainer position="top-right" autoClose={5000} />
      <div className="form-box login">
        <form onSubmit={handleLoginSubmit}>
          <h1>Student Login</h1>
          <input type="text" name="email" placeholder="Email" value={studLoginInfo.email} onChange={(e) => setStudLoginInfo({ ...studLoginInfo, email: e.target.value })} required />
          <input type="password" name="password" placeholder="Password" value={studLoginInfo.password} onChange={(e) => setStudLoginInfo({ ...studLoginInfo, password: e.target.value })} required />
          <button type="submit">Login</button>
        </form>
      </div>
      <div className="form-box register">
        <form onSubmit={handleSignupSubmit}>
          <h1>Student Registration</h1>
          <input type="text" name="name" placeholder="Full Name" value={studSignupInfo.name} onChange={(e) => setStudSignupInfo({ ...studSignupInfo, name: e.target.value })} required />
          <input type="email" name="email" placeholder="Email" value={studSignupInfo.email} onChange={(e) => setStudSignupInfo({ ...studSignupInfo, email: e.target.value })} required />
          <input type="password" name="password" placeholder="Password" value={studSignupInfo.password} onChange={(e) => setStudSignupInfo({ ...studSignupInfo, password: e.target.value })} required />
          <input type="text" name="college" placeholder="College Name" value={studSignupInfo.college} onChange={(e) => setStudSignupInfo({ ...studSignupInfo, college: e.target.value })} required />
          <button type="submit">Register</button>
        </form>
      </div>
      <div className="toggle-box">
        <div className="toggle-panel toggle-left">
          <h1>Welcome!</h1>
          <p>Don't have an account?</p>
          <button onClick={() => setIsActive(true)}>Register</button>
        </div>
        <div className="toggle-panel toggle-right">
          <h1>Welcome Back!</h1>
          <p>Already have an account?</p>
          <button onClick={() => setIsActive(false)}>Login</button>
        </div>
      </div>
    </div>
  );
};

export default StudLogin;