import React from 'react'

function StudSignup(){
    return(
        <div>Signup</div>
    )
}
export default StudSignup;