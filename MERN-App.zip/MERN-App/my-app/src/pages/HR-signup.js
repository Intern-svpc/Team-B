import React from 'react'
import './HR-signup.css'

function HRSignup(){
    return(
        <div>signup</div>
    )
}
export default HRSignup;