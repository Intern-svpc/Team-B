const mongoose = require('mongoose');

const mongo_url = "mongodb://himanshupethe08092003:Him%40nshu08092003p@cluster1-shard-00-00.5hnfc.mongodb.net:27017,cluster1-shard-00-01.5hnfc.mongodb.net:27017,cluster1-shard-00-02.5hnfc.mongodb.net:27017/Student?ssl=true&replicaSet=atlas-1th3yt-shard-0&authSource=admin&retryWrites=true&w=majority";

mongoose.connect(mongo_url, {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log('✅ MongoDB Connected Successfully!'))
.catch(err => console.error('❌ MongoDB Connection Error:', err));
