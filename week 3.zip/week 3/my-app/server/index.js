require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const mongoose = require('mongoose');
const Joi = require('joi');


const app = express();
app.use(cors({ origin: "http://localhost:3000", credentials: true }));
app.use(bodyParser.json());

// Database Connection
mongoose.connect("mongodb://localhost:27017/students", {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
    .then(() => console.log('MongoDB Connected...'))
    .catch(err => console.error('MongoDB Connection Error:', err));

// Schemas & Models
const JDSSchema = new mongoose.Schema({
    hrId: { type: mongoose.Schema.Types.ObjectId, ref: "HR", required: true },
    position: String,
    description: String,
    location: String,
    type: String,
    skills: String,
    date: { type: String, default: new Date().toISOString().split("T")[0] },
    ctc: String,
    status: { type: Number, enum: [0, 1, 2], default: 2 }
}, { collection: "jds" });

const HRSchemas = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, unique: true, required: true },
    password: { type: String, required: true },
    company: { type: String, required: true }
}, { collection: "hrs" });

const StudentSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true }
});

const JD = mongoose.model("JD", JDSSchema);
const HR = mongoose.model("HR", HRSchemas);
const StudentModel = mongoose.model('student_logins', StudentSchema);

// Middleware Authentication
const ensureAuthenticated = (req, res, next) => {
    const authHeader = req.headers.authorization || req.headers.Authorization;
    console.log("Auth header:", authHeader);

    if (!authHeader) return res.status(403).json({ message: 'Access denied. Token required.' });
    
    const token = authHeader.split(' ')[1];
    console.log("Token extracted:", token ? "Token exists" : "No token"); 

    if (!token) return res.status(403).json({ message: 'Access denied. Invalid token format.' });
    
    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = decoded;
        next();
    } catch (err) {
        res.status(403).json({ message: 'Access denied. Invalid token.' });
    }
};

// Validation Middleware
const signupValidation = (req, res, next) => {
    const schema = Joi.object({
        name: Joi.string().min(3).required(),
        email: Joi.string().email().required(),
        password: Joi.string().min(6).required(),
        company: Joi.string().optional()
    });
    const { error } = schema.validate(req.body);
    if (error) return res.status(400).json({ success: false, message: error.details[0].message });
    next();
};

const loginValidation = (req, res, next) => {
    const schema = Joi.object({
        email: Joi.string().email().required(),
        password: Joi.string().required()
    });
    const { error } = schema.validate(req.body);
    if (error) return res.status(400).json({ success: false, message: error.details[0].message });
    next();
};

const jdValidation = (req, res, next) => {
    const schema = Joi.object({
        position: Joi.string().required(),
        type: Joi.string().required(),
        location: Joi.string().required(),
        description: Joi.string().required(),
        skills: Joi.string().required(),
        date: Joi.date().required(),
        ctc: Joi.string().required()
    });
    const { error } = schema.validate(req.body);
    if (error) return res.status(400).json({ error: error.details[0].message });
    next();
};

// HR Routes
app.post('/hr/signup', signupValidation, async (req, res) => {
    try {
        const { name, email, password, company } = req.body;
        if (await HR.findOne({ email })) return res.status(400).json({ success: false, message: 'HR already registered' });
        const newHR = new HR({ name, email, password: await bcrypt.hash(password, 10), company });
        await newHR.save();
        res.status(201).json({ success: true, message: 'HR registered successfully' });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Internal server error', error: error.message });
    }
});

app.post('/hr/login', loginValidation, async (req, res) => {
    try {
        const { email, password } = req.body;
        const hr = await HR.findOne({ email });
        if (!hr || !(await bcrypt.compare(password, hr.password))) return res.status(400).json({ success: false, message: 'Invalid credentials.' });
        const token = jwt.sign({ id: hr._id, email: hr.email, company: hr.company }, process.env.JWT_SECRET, { expiresIn: '1h' });
        
        res.status(200).json({ success: true, message: 'Login successful', token, hr });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error', error: error.message });
    }
});

// JD Routes
app.post('/hr/jds', ensureAuthenticated, jdValidation, async (req, res) => {
    try {
        // const hr = await HR.findById(req.user.id);
        // if (!hr) return res.status(404).json({ success: false, message: 'HR not found' });
        const newJD = new JD({
            hrId: req.user.id,  // Use the hrId from the token
            ...req.body
        });
        await newJD.save();

        res.status(201).json({ success: true, message: 'Job Description added successfully', jd: newJD });
    } catch (error) {
        console.error("Error creating JD:", error); 
        res.status(500).json({ success: false, error: 'Internal server error' });
    }
});

app.get('/hr/jds', ensureAuthenticated, async (req, res) => {
    try {
        const jds = await JD.find({ hrId: req.user.id });
        res.status(200).json({ success: true, jds: jds });
    } catch (error) {
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Student Routes
app.post('/stud/signup', signupValidation, async (req, res) => {
    try {
        const { name, email, password } = req.body;
        if (await StudentModel.findOne({ email })) return res.status(409).json({ success: false, message: 'User already exists' });
        const newStudent = new StudentModel({ name, email, password: await bcrypt.hash(password, 10) });
        await newStudent.save();
        res.status(201).json({ success: true, message: 'Signup successful' });
    } catch (err) {
        res.status(500).json({ success: false, message: 'Internal Server Error', error: err.message });
    }
});

app.post('/stud/login', loginValidation, async (req, res) => {
    try {
        const { email, password } = req.body;
        const student = await StudentModel.findOne({ email });
        if (!student || !(await bcrypt.compare(password, student.password))) {
            return res.status(400).json({ success: false, message: 'Invalid credentials.' });
        }
        const token = jwt.sign({ id: student._id, email: student.email }, process.env.JWT_SECRET, { expiresIn: '1h' });
        res.status(200).json({ success: true, message: 'Login successful', token, student });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Server error', error: error.message });
    }
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
