import React, { useEffect, useState } from "react";
import './Admin.css';

const Admin = () => {
    const [hrCount, setHrCount] = useState(0);
    const [opportunityCount, setOpportunityCount] = useState(0);
    const [jdRequests, setJdRequests] = useState([
        {
            position: "Software Engineer",
            type: "Full-time",
            location: "New York",
            company: "Google",
            skills: "JavaScript, React, Node.js",
            description: "We are looking for a Software Engineer to join our dynamic team.",
            responsibilities: [
                "Develop and maintain web applications",
                "Collaborate with cross-functional teams",
                "Write clean, maintainable code",
                "Participate in code reviews",
            ],
            requirements: [
                "Strong proficiency in JavaScript and React",
                "Bachelor's degree in Computer Science or related field",
                "Experience with agile development methodologies",
            ],
            ctc: "24-30 LPA",
            postDate: "2024-02-01",
            workMode: "Hybrid",
            expanded: false,
        },
        {
            position: "Data Analyst",
            type: "Contract",
            location: "San Francisco",
            company: "Microsoft",
            skills: "Python, SQL, Tableau",
            description: "Looking for a Data Analyst to help drive business decisions.",
            responsibilities: [
                "Analyze complex data sets",
                "Create dashboards and reports",
                "Identify trends and patterns",
                "Present findings to stakeholders",
            ],
            requirements: [
                "2+ years of experience in data analysis",
                "Proficiency in SQL and Python",
                "Experience with visualization tools",
            ],
            ctc: "18-22 LPA",
            postDate: "2024-02-03",
            workMode: "Remote",
            expanded: false,
        },
    ]);

    useEffect(() => {
        setHrCount(25);
        setOpportunityCount(10);
    }, []);

    const toggleExpand = (index) => {
        setJdRequests(jdRequests.map((jd, i) => (i === index ? { ...jd, expanded: !jd.expanded } : jd)));
    };

    return (
        <div style={{ padding: "20px", background: "#f0f2f5" }}>
            <div className="header">Admin Panel</div>
            <div className="stats-container">
                <div className="stats-box">
                    <h2>No. of HR (Human Resources)</h2>
                    <p>{hrCount}</p>
                </div>
                <div className="stats-box">
                    <h2>No. of Opportunities</h2>
                    <p>{opportunityCount}</p>
                </div>
            </div>
            <div className="jd-list">
                <h2>Job Description Requests</h2>
                {jdRequests.map((jd, index) => (
                    <div key={index} className="jd-item" onClick={() => toggleExpand(index)}>
                        <div className="jd-header">
                            <div className="jd-details">
                                <h3>{jd.position}</h3>
                                <p><strong>Company:</strong> {jd.company}</p>
                                <p><strong>Location:</strong> {jd.location}</p>
                                <p><strong>CTC:</strong> {jd.ctc}</p>
                            </div>
                        </div>
                        {jd.expanded && (
                            <div className="jd-expanded active">
                                <div className="detail-section">
                                    <h4>Responsibilities:</h4>
                                    <ul>{jd.responsibilities.map((res, i) => <li key={i}>{res}</li>)}</ul>
                                </div>
                                <div className="detail-section">
                                    <h4>Requirements:</h4>
                                    <ul>{jd.requirements.map((req, i) => <li key={i}>{req}</li>)}</ul>
                                </div>
                            </div>
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Admin;