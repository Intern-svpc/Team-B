import React, { useState, useEffect } from 'react'; // Added useEffect
import './StudLogin.css';
import { ToastContainer, toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom'; // Add this import
import { handleError, handleSuccess } from '../utils';


const LoginSignup = () => {
  const [isActive, setIsActive] = useState(false);
  const [StudLoginInfo, setStudLoginInfo] = useState({ email: '', password: '' });
  const [StudSignupInfo, setStudSignupInfo] = useState({
    name: '',
    email: '',
    password: ''
  });
const navigate = useNavigate();
  useEffect(() => {
    document.title = isActive ? "Register - Student Portal" : "Login - Student Portal";
  }, [isActive]); // Runs when isActive changes

  const handleSignupSubmit = async (e) => {
    e.preventDefault();
    const {name, email, password} = StudSignupInfo;
    if(!name || !email || !password){
      return handleError("name, email, password are required")
    }
    try {
      const url = "http://localhost:8080/stud/signup";
      const response = await fetch(url, {
        method:'POST',
        headers: {
          'Content-Type': 'application/json',
          },
          body: JSON.stringify(StudSignupInfo)
      });
      const result = await response.json();
      
      const {success, message, error} = result;
      if(success){
        handleSuccess(message);
        setTimeout(()=>{
          setIsActive(false);
      setStudSignupInfo({ name: '', email: '', password: '' });
      // Auto-fill login email
      setStudLoginInfo(prev => ({ ...prev, email }));
        }, 1000)
      }else if (error){
        const details = error?.details[0].message;
        handleError(details);
      }
      else if(!success){
        handleError(message);
      }
      console.log(result);
    }
    catch(err){
      handleError(err);
    }
  };

  const handleLoginSubmit = async (e) => {
    e.preventDefault();
    const {email, password} = StudLoginInfo;
    if(!email || !password){
      return handleError("email, password are required")
    }
    try {
      const url = "http://localhost:8080/stud/login";
      const response = await fetch(url, {
        method:'POST',
        headers: {
          'Content-Type': 'application/json',
          },
          body: JSON.stringify(StudLoginInfo)
      });
      const result = await response.json();
      
      const {success, message, error, jwtToken, name} = result;
      if(success){
        handleSuccess(message);
        localStorage.setItem('token', jwtToken);
        localStorage.setItem('loggedInUser', name);
        setTimeout(()=>{
          navigate('/Student-home')
      setStudLoginInfo({email: '', password: '' });
      // Auto-fill login email
      // setStudLoginInfo(prev => ({ ...prev, email }));
        }, 1000)
      }else if (error){
        const details = error?.details[0].message;
        handleError(details);
      }
      else if(!success){
        handleError(message);
      }
      console.log(result);
    }
    catch(err){
      handleError(err);
    }
  };

  const handleSignupChange = (e) =>{
    const { name, value } = e.target;
    console.log(name, value);
    const copyStudSignInfo = {...StudSignupInfo};
    copyStudSignInfo[name] = value;
    setStudSignupInfo(copyStudSignInfo);
  }

  const handleLoginChange = (e) =>{
    const { name, value } = e.target;
    console.log(name, value);
    const copyStudLoginInfo = {...StudLoginInfo};
    copyStudLoginInfo[name] = value;
    setStudLoginInfo(copyStudLoginInfo);
  }



  return (
    
    <div className={`container ${isActive ? 'active' : ''}`}>
      <ToastContainer
  position="top-right"
  autoClose={5000}
  hideProgressBar={false}
  newestOnTop={false}
  closeOnClick
  rtl={false}
  pauseOnFocusLoss
  draggable
  pauseOnHover
  theme="colored" // or "dark"
/>
      {/* Login Form */}
      <div className="form-box login">
        <form onSubmit={handleLoginSubmit}>
          <h1>Student Login</h1>
          <div className="input-box">
            <input 
              type="text" 
              name="email"
              placeholder="email" 
              required 
              value={StudLoginInfo.name}
              onChange={handleLoginChange}
            />
            <i className='bx bxs-user'></i>
          </div>
          <div className="input-box">
            <input 
              type="password" 
              name="password"
              placeholder="Password" 
              required 
              value={StudLoginInfo.password}
              onChange={handleLoginChange}
            />
            <i className='bx bxs-lock-alt' ></i>
          </div>
          {/* <div className="forgot-link">
            <a href="#">Forgot Password?</a>
          </div> */}
          <button type="submit" className="btn">Login</button>
          {/* <p>or login with social platforms</p> */}
          {/* <div className="social-icons">
            <a href="#"><i className='bx bxl-google' ></i></a>
            <a href="#"><i className='bx bxl-facebook' ></i></a>
            <a href="#"><i className='bx bxl-github' ></i></a>
            <a href="#"><i className='bx bxl-linkedin' ></i></a>
          </div> */}
        </form>
      </div>

      {/* Registration Form */}
      <div className="form-box register">
        <form onSubmit={handleSignupSubmit}>
          <h1>Student Registration</h1>
          <div className="input-box">
            <input 
              type="text" 
              name="name"
              placeholder="Username" 
              required 
              value={StudSignupInfo.name}
              onChange={handleSignupChange}
            />
            <i className='bx bxs-user'></i>
          </div>
          <div className="input-box">
            <input 
              type="email" 
              name="email"
              placeholder="Email" 
              // required 
              value={StudSignupInfo.email}
              onChange={handleSignupChange}
            />
            <i className='bx bxs-envelope' ></i>
          </div>
          <div className="input-box">
            <input 
              type="password" 
              name="password"
              placeholder="Password" 
              // required 
              value={StudSignupInfo.password}
              onChange={handleSignupChange}
            />
            <i className='bx bxs-lock-alt' ></i>
          </div>
          <button type="submit" className="btn">Register</button>
          {/* <p>or register with social platforms</p> */}
          {/* <div className="social-icons">
            <a href="#"><i className='bx bxl-google' ></i></a>
            <a href="#"><i className='bx bxl-facebook' ></i></a>
            <a href="#"><i className='bx bxl-github' ></i></a>
            <a href="#"><i className='bx bxl-linkedin' ></i></a>
          </div> */}
        </form>
      </div>

      {/* Toggle Section */}
      <div className="toggle-box">
        <div className="toggle-panel toggle-left">
          <h1>Hello, Welcome!</h1>
          <p>Don't have an account?</p>
          <button className="btn" onClick={() => setIsActive(true)}>Register</button>
        </div>
        <div className="toggle-panel toggle-right">
          <h1>Welcome Back!</h1>
          <p>Already have an account?</p>
          <button className="btn" onClick={() => setIsActive(false)}>Login</button>
        </div>
      </div>
      {/* <ToastContainer /> */}
    </div>
    
  );
};

export default LoginSignup;