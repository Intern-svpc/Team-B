import React, { useState, useEffect } from "react";
import "./HR-home.css";

const HRPanel = () => {
    const [showJDBox, setShowJDBox] = useState(false);
    const [ongoingJDs, setOngoingJDs] = useState([]);
    const [closedJDs, setClosedJDs] = useState([]);
    const [currentView, setCurrentView] = useState("");
    const [formData, setFormData] = useState({
        position: "",
        type: "Full-time", // Default selection
        location: "",
        description: "",
        skills: "",
        date: new Date().toISOString().split("T")[0], // Auto-set date
        ctc: ""
    });

    useEffect(() => {
        fetchJDs();
    }, []);

    const fetchJDs = async () => {
        const token = localStorage.getItem("token");
        if (!token) {
            alert("Authentication token is missing. Please log in again.");
            return;
        }
        try {
            const response = await fetch("http://localhost:8080/hr/jds", {
                method: "GET",
                headers: {
                    "Authorization": `Bearer ${token}`
                }
            });
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            const data = await response.json();
            setOngoingJDs(data.jds);
            setClosedJDs([]);
        } catch (error) {
            console.error("Error fetching JDs:", error);
            alert("An error occurred while fetching the JDs.");
        }
    };

    const handleInputChange = (e) => {
        setFormData({ ...formData, [e.target.id]: e.target.value });
    };
    const handleDropdownChange = (e) => {
        setFormData({ ...formData, type: e.target.value });
    };

    const handleFormSubmit = async (e) => {
        e.preventDefault();
        const token = localStorage.getItem("token");
        if (!token) {
            alert("Authentication token is missing. Please log in again.");
            return;
        }
        const dataToSubmit = {
            ...formData,
            date: formData.date || new Date().toISOString().split("T")[0]
        };
        try {
            console.log("Submitting JD:", dataToSubmit); // Debug log
            const response = await fetch("http://localhost:8080/hr/jds", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`
                },
                body: JSON.stringify(dataToSubmit),
            });
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            const result = await response.json();
        console.log("JD submission result:", result);
        
        alert("Job Description submitted successfully!");
            await fetchJDs();
        } catch (error) {
            console.error("Error submitting JD:", error);
            alert("An error occurred while submitting the JD.");
        }
        setFormData({
            position: "",
            type: "Full-time",
            location: "",
            description: "",
            skills: "",
            date: new Date().toISOString().split("T")[0],
            ctc: ""
        });
        setShowJDBox(false);
    };

    const closeJD = async (index) => {
        const jdToClose = ongoingJDs[index];
        try {
            const token = localStorage.getItem("token");
            if (!token) {
                alert("Authentication token is missing. Please log in again.");
                return;
            }
            await fetch(`http://localhost:8080/hr/jds/${jdToClose.id}/close`, {
                method: "PUT",
                headers: {
                    "Authorization": `Bearer ${token}`
                }
            });
            await fetchJDs();
        } catch (error) {
            console.error("Error closing JD:", error);
            alert("An error occurred while closing the JD.");
        }
    };

    return (
        <div className="hr-panel">
            <div className="header">HR Panel</div>
            <div className="button-container">
                <button onClick={() => setShowJDBox(!showJDBox)}>Add JD</button>
                <button onClick={() => setCurrentView("ongoing")}>Ongoing JD</button>
                <button onClick={() => setCurrentView("closed")}>Closed JD</button>
            </div>
            
            {showJDBox && (
                <div className="add-jd-box">
                    <h3>Add Job Description</h3>
                    <form onSubmit={handleFormSubmit}>
                        <input type="text" id="position" value={formData.position} placeholder="Position" onChange={handleInputChange} required />
                        <select id="type" value={formData.type} onChange={handleDropdownChange} required>
                            <option value="Full-time">Full-time</option>
                            <option value="Part-time">Part-time</option>
                            <option value="Internship">Internship</option>
                        </select>
                        <input type="text" id="location" value={formData.location} placeholder="Location" onChange={handleInputChange} required />
                        <textarea id="description" value={formData.description} placeholder="Description" onChange={handleInputChange} required />
                        <input type="text" id="skills" value={formData.skills} placeholder="Skills Required" onChange={handleInputChange} required />
                        <input type="text" id="ctc" value={formData.ctc} placeholder="CTC" onChange={handleInputChange} required />
                        <input type="text" id="date" value={formData.date} readOnly />
                        <div className="form-buttons">
                            <button type="submit">Submit</button>
                        </div>
                    </form>
                </div>
            )}

            {currentView === "ongoing" && (
                <div className="jd-list">
                    <h3>Ongoing Job Descriptions</h3>
                    {ongoingJDs.map((jd, index) => (
                        <div key={jd.id} className="jd-item">
                            <h4>{jd.position} ({jd.type})</h4>
                            <p><strong>Location:</strong> {jd.location}</p>
                            <p><strong>Skills:</strong> {jd.skills}</p>
                            <button className="close-btn" onClick={() => closeJD(index)}>Close</button>
                        </div>
                    ))}
                </div>
            )}

            {currentView === "closed" && (
                <div className="jd-list">
                    <h3>Closed Job Descriptions</h3>
                    {closedJDs.map((jd) => (
                        <div key={jd.id} className="jd-item">
                            <h4>{jd.position} ({jd.type})</h4>
                            <p><strong>Location:</strong> {jd.location}</p>
                            <p><strong>Skills:</strong> {jd.skills}</p>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default HRPanel;
